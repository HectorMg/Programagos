# Programagos
Proyecto final de intro

## Descarga

Para descargar el proyecto naveguen a un directorio donde van a querer guarderlo y desde la terminal, si tienen instalado git, pueden hacer:

`git clone https://github.com/HectorMg/Programagos.git`

Para correrlo tienen que descargar e instalar node-webkit o nw. Node-webkit basicamente combina un browser webkit con nodejs y provee una manera de hacer aplicaciones GUI con las librerías nativas de cada OS. Si tienen node y npm instalado pueden correr

`npm -g install nw`

Si no tiene npm aquí les dejo el link al git de nw donde vienen instrucciones: [https://github.com/nwjs/nw.js/](https://github.com/nwjs/nw.js/)

Una vez instalado nw, naveguen al mismo directorio de antes y corran:

`nw .`

Si les da error de resources/player.png not found. Es porque no subí las imagenes que estaba usando de prueba al git entonces van a tener que hacerlas.

Con que guarden una imagen dentro de un folder 'resources' y la renombren 'player.png', debería de jalar.
El folder resources deberá estar adentro del folder de su proyecto.
